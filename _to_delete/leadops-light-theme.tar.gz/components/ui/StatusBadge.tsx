import { cn } from '@/lib/utils';
import type { EventStatus } from '@/lib/ag-ui/types';

/**
 * Status is never carried by colour alone — every badge renders a dot AND its
 * label. That pairing is what keeps `triggered` (amber) and `failed` (red)
 * separable for red-green colour-blind readers, where the two hues sit close
 * together.
 */
const STATUS_META: Record<
  EventStatus,
  { label: string; dot: string; text: string; wash: string; ring: string }
> = {
  success: {
    label: 'Success',
    dot: 'bg-status-success',
    text: 'text-status-success',
    wash: 'bg-status-wash-success',
    ring: 'ring-status-ring-success',
  },
  running: {
    label: 'Running',
    dot: 'bg-status-running',
    text: 'text-status-running',
    wash: 'bg-status-wash-running',
    ring: 'ring-status-ring-running',
  },
  triggered: {
    label: 'Triggered',
    dot: 'bg-status-triggered',
    text: 'text-status-triggered',
    wash: 'bg-status-wash-triggered',
    ring: 'ring-status-ring-triggered',
  },
  waiting: {
    label: 'Waiting',
    dot: 'bg-status-waiting',
    text: 'text-status-waiting',
    wash: 'bg-status-wash-waiting',
    ring: 'ring-status-ring-waiting',
  },
  failed: {
    label: 'Failed',
    dot: 'bg-status-failed',
    text: 'text-status-failed',
    wash: 'bg-status-wash-failed',
    ring: 'ring-status-ring-failed',
  },
};

export function StatusBadge({
  status,
  pulse = false,
  className,
}: {
  status: EventStatus;
  pulse?: boolean;
  className?: string;
}) {
  const meta = STATUS_META[status];
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-2xs font-medium ring-1 ring-inset',
        meta.wash,
        meta.text,
        meta.ring,
        className
      )}
    >
      <span
        className={cn('h-1.5 w-1.5 rounded-full', meta.dot, pulse && 'animate-pulseDot')}
        aria-hidden
      />
      {meta.label}
    </span>
  );
}
