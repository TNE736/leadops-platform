import { cn } from '@/lib/utils';

export type PanelTone = 'default' | 'success' | 'warning' | 'danger' | 'info';

interface PanelProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  title?: React.ReactNode;
  eyebrow?: string;
  description?: string;
  /** Right-aligned controls in the panel header (filters, links, counts). */
  actions?: React.ReactNode;
  /** Subtle left-edge tint. Reserved for state, not decoration. */
  tone?: PanelTone;
  /** Remove body padding so tables and full-bleed lists sit flush to the edges. */
  flush?: boolean;
  bodyClassName?: string;
}

const TONE_EDGE: Record<PanelTone, string> = {
  default: '',
  success: 'before:bg-status-success',
  warning: 'before:bg-status-triggered',
  danger: 'before:bg-status-failed',
  info: 'before:bg-status-running',
};

/**
 * The single card primitive every page is built from: white surface, hairline
 * border, one soft shadow. A `tone` adds a 3px left edge — used only to signal
 * state (healthy / degraded / failed), never for decoration.
 */
export function Panel({
  title,
  eyebrow,
  description,
  actions,
  tone = 'default',
  flush = false,
  className,
  bodyClassName,
  children,
  ...props
}: PanelProps) {
  const hasHeader = Boolean(eyebrow || title || description || actions);

  return (
    <section
      className={cn(
        'relative overflow-hidden rounded-lg border border-line bg-surface shadow-card',
        tone !== 'default' &&
          'before:absolute before:inset-y-0 before:left-0 before:w-[3px] before:content-[""]',
        TONE_EDGE[tone],
        className
      )}
      {...props}
    >
      {hasHeader && (
        <header
          className={cn(
            'flex items-start justify-between gap-4 px-5 py-4',
            !flush && 'border-b border-line-soft'
          )}
        >
          <div className="min-w-0">
            {eyebrow && (
              <p className="mb-0.5 text-2xs font-semibold uppercase tracking-wider text-ink-faint">
                {eyebrow}
              </p>
            )}
            {title && (
              <h2 className="truncate text-sm font-semibold text-ink">{title}</h2>
            )}
            {description && (
              <p className="mt-1 max-w-2xl text-xs leading-relaxed text-ink-muted">
                {description}
              </p>
            )}
          </div>
          {actions && <div className="shrink-0">{actions}</div>}
        </header>
      )}
      <div className={cn(!flush && 'px-5 py-4', bodyClassName)}>{children}</div>
    </section>
  );
}
