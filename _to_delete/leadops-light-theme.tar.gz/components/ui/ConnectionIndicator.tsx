'use client';

import { Loader2 } from 'lucide-react';
import { useAGUIState } from '@/lib/ag-ui/provider';
import { cn } from '@/lib/utils';

const CONFIG = {
  connecting: {
    label: 'Connecting',
    long: 'Connecting…',
    wash: 'bg-status-wash-waiting',
    ring: 'ring-status-ring-waiting',
    text: 'text-status-waiting',
    dot: 'bg-status-waiting',
    spin: true,
  },
  open: {
    label: 'Live',
    long: 'Live · streaming',
    wash: 'bg-status-wash-success',
    ring: 'ring-status-ring-success',
    text: 'text-status-success',
    dot: 'bg-status-success',
    spin: false,
  },
  closed: {
    label: 'Offline',
    long: 'Disconnected',
    wash: 'bg-status-wash-waiting',
    ring: 'ring-status-ring-waiting',
    text: 'text-status-waiting',
    dot: 'bg-status-waiting',
    spin: false,
  },
  error: {
    label: 'Error',
    long: 'Connection error',
    wash: 'bg-status-wash-failed',
    ring: 'ring-status-ring-failed',
    text: 'text-status-failed',
    dot: 'bg-status-failed',
    spin: false,
  },
} as const;

export function ConnectionIndicator({ long = false }: { long?: boolean }) {
  const { connection } = useAGUIState();
  const config = CONFIG[connection];

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset',
        config.wash,
        config.text,
        config.ring
      )}
    >
      {config.spin ? (
        <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
      ) : (
        <span
          className={cn(
            'h-1.5 w-1.5 rounded-full',
            config.dot,
            connection === 'open' && 'animate-pulseDot'
          )}
          aria-hidden
        />
      )}
      {long ? config.long : config.label}
    </span>
  );
}
