'use client';

import type { AGUIEvent } from '@/lib/ag-ui/types';
import { STAGE_LABELS, SOURCE_LABELS } from '@/lib/ag-ui/types';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { formatRelativeTime } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function EventFeed({
  events,
  emptyLabel,
  showSource = true,
  className,
}: {
  events: AGUIEvent[];
  emptyLabel?: string;
  showSource?: boolean;
  className?: string;
}) {
  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-1 px-5 py-10 text-center">
        <p className="text-sm text-ink-muted">
          {emptyLabel ?? 'No events yet.'}
        </p>
        <p className="text-xs text-ink-faint">
          Events appear here as soon as the stream delivers them.
        </p>
      </div>
    );
  }

  return (
    <ul className={cn('divide-y divide-line-soft', className)}>
      {events.map((evt) => (
        <li
          key={evt.id}
          className="flex items-center justify-between gap-4 px-5 py-3 transition-colors hover:bg-surface-sunken"
        >
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <span className="truncate font-mono text-xs font-medium text-ink">{evt.type}</span>
              {evt.leadId && (
                <span className="rounded bg-surface-sunken px-1.5 py-0.5 font-mono text-2xs text-ink-muted ring-1 ring-inset ring-line">
                  {evt.leadId}
                </span>
              )}
            </div>
            <p className="mt-0.5 truncate text-xs text-ink-muted">
              {STAGE_LABELS[evt.type]}
              {showSource && (
                <>
                  <span className="mx-1.5 text-ink-faint">·</span>
                  <span className="text-ink-faint">{SOURCE_LABELS[evt.source]}</span>
                </>
              )}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            <StatusBadge status={evt.status} pulse={evt.status === 'running'} />
            <time
              dateTime={evt.timestamp}
              className="w-16 text-right text-2xs tabular-nums text-ink-faint"
            >
              {formatRelativeTime(evt.timestamp)}
            </time>
          </div>
        </li>
      ))}
    </ul>
  );
}
