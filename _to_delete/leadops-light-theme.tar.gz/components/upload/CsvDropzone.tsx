'use client';

import { useCallback, useRef, useState } from 'react';
import { UploadCloud } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Drop zone for adding CSV files to the upload queue. Selection alone never
 * triggers ingestion — that only happens when the page's Upload button is clicked.
 */
export function CsvDropzone({
  onFiles,
  queuedCount = 0,
}: {
  onFiles: (files: File[]) => void;
  queuedCount?: number;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFiles = useCallback(
    (fileList: FileList | null) => {
      if (!fileList) return;
      const csvFiles = Array.from(fileList).filter(
        (f) => f.name.toLowerCase().endsWith('.csv') || f.type === 'text/csv'
      );
      if (csvFiles.length > 0) onFiles(csvFiles);
    },
    [onFiles]
  );

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handleFiles(e.dataTransfer.files);
      }}
      onClick={() => inputRef.current?.click()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click();
      }}
      className={cn(
        'flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border border-dashed px-6 py-10 text-center transition-colors',
        dragging
          ? 'border-brand-blue bg-brand-wash'
          : 'border-line-strong bg-surface-sunken hover:border-brand-blue/60 hover:bg-brand-wash/60'
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".csv,text/csv"
        multiple
        className="hidden"
        onChange={(e) => {
          handleFiles(e.target.files);
          // Allow selecting the same file again after removing it from the queue.
          e.target.value = '';
        }}
      />
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-surface shadow-card ring-1 ring-line">
        <UploadCloud className="h-5 w-5 text-ink-muted" />
      </span>
      <p className="mt-1 text-sm font-medium text-ink">
        {queuedCount > 0
          ? 'Drop more CSVs here, or click to add another'
          : 'Drop your leads CSV here, or click to browse'}
      </p>
      <p className="text-xs text-ink-muted">CSV files only · parsed in your browser</p>
    </div>
  );
}
