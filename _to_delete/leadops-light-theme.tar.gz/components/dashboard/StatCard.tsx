import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export type StatTone = 'default' | 'success' | 'failed';

/**
 * A stat tile, not a chart: one number is the whole story, so it gets size and
 * weight rather than a plot. The value stays in ink by default — colour is
 * applied only when the number itself carries state (failures, completions).
 */
export function StatCard({
  label,
  value,
  hint,
  tone = 'default',
  icon: Icon,
}: {
  label: string;
  value: string | number;
  hint?: string;
  tone?: StatTone;
  icon?: LucideIcon;
}) {
  return (
    <div className="rounded-lg border border-line bg-surface px-4 py-3.5 shadow-card">
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-2xs font-semibold uppercase tracking-wider text-ink-faint">
          {label}
        </p>
        {Icon && <Icon className="h-4 w-4 shrink-0 text-ink-faint" aria-hidden />}
      </div>
      <p
        className={cn(
          'mt-1.5 text-3xl font-semibold leading-none tracking-tight',
          tone === 'success' && 'text-status-success',
          tone === 'failed' && 'text-status-failed',
          tone === 'default' && 'text-ink'
        )}
      >
        {value}
      </p>
      {hint && <p className="mt-1.5 text-xs text-ink-muted">{hint}</p>}
    </div>
  );
}
