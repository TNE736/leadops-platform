'use client';

import { usePipelineCounts } from '@/lib/ag-ui/provider';
import { STAGE_LABELS } from '@/lib/ag-ui/types';
import { cn } from '@/lib/utils';

/**
 * The pipeline stage grid: lead.created → … → crm.updated.
 *
 * Deliberately NOT colour-coded per stage — eight hues side by side would read
 * as a rainbow and imply eight unrelated categories. Stages are one ordered
 * sequence, so order is carried by the step numbers and reading order, and
 * colour is reserved for the single distinction that matters: has this stage
 * seen traffic, or not.
 *
 * Wraps to a grid rather than scrolling horizontally, so no stage name is ever
 * clipped off the right edge of the card.
 */
export function EventPipeline() {
  const stages = usePipelineCounts();

  return (
    <ol className="grid grid-cols-1 gap-3 px-5 py-4 sm:grid-cols-2 lg:grid-cols-4">
      {stages.map(({ stage, count }, idx) => {
        const active = count > 0;
        return (
          <li
            key={stage}
            className={cn(
              'flex items-start gap-3 rounded-lg border px-3.5 py-3 transition-colors',
              active ? 'border-line bg-surface shadow-card' : 'border-line-soft bg-surface-sunken'
            )}
          >
            <span
              className={cn(
                'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-2xs font-semibold tabular-nums',
                active
                  ? 'bg-brand-gradient text-white'
                  : 'bg-surface text-ink-faint ring-1 ring-inset ring-line'
              )}
            >
              {idx + 1}
            </span>

            <div className="min-w-0 flex-1">
              <p
                className={cn(
                  'text-xs font-medium leading-snug',
                  active ? 'text-ink' : 'text-ink-muted'
                )}
              >
                {STAGE_LABELS[stage]}
              </p>
              <p
                className="mt-0.5 truncate font-mono text-2xs text-ink-faint"
                title={stage}
              >
                {stage}
              </p>
            </div>

            <span
              className={cn(
                'shrink-0 text-lg font-semibold leading-none tabular-nums',
                active ? 'text-ink' : 'text-ink-faint'
              )}
            >
              {count}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
