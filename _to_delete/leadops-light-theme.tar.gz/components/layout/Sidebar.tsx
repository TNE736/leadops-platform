'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Radio } from 'lucide-react';
import { cn } from '@/lib/utils';
import { NAV_GROUPS, FOOTER_NAV, type NavItem } from '@/components/layout/nav';
import { useAGUIState } from '@/lib/ag-ui/provider';

function NavLink({ item, active, badge }: { item: NavItem; active: boolean; badge?: number }) {
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      aria-current={active ? 'page' : undefined}
      className={cn(
        'group relative flex items-center gap-2.5 rounded-md py-2 pl-3 pr-2.5 text-sm transition-colors',
        active
          ? 'bg-brand-wash font-medium text-brand-ink'
          : 'text-ink-secondary hover:bg-surface-hover hover:text-ink'
      )}
    >
      {/* Active rail carries the brand gradient — the one place colour is decorative. */}
      {active && (
        <span
          aria-hidden
          className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-brand-gradient"
        />
      )}
      <Icon
        className={cn(
          'h-4 w-4 shrink-0',
          active ? 'text-brand-ink' : 'text-ink-faint group-hover:text-ink-muted'
        )}
      />
      <span className="truncate">{item.label}</span>
      {typeof badge === 'number' && badge > 0 && (
        <span className="ml-auto rounded-full bg-status-wash-failed px-1.5 py-0.5 text-2xs font-semibold tabular-nums text-status-failed ring-1 ring-inset ring-status-ring-failed">
          {badge}
        </span>
      )}
    </Link>
  );
}

export function Sidebar() {
  const pathname = usePathname();
  const { events } = useAGUIState();
  const alertCount = events.filter(
    (e) => e.status === 'failed' || e.type === 'error.occurred'
  ).length;

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex">
      {/* Brand */}
      <div className="flex h-14 shrink-0 items-center gap-2.5 border-b border-line px-5">
        <span className="flex h-7 w-7 items-center justify-center rounded-md bg-brand-gradient">
          <Radio className="h-4 w-4 text-white" />
        </span>
        <div className="min-w-0 leading-tight">
          <p className="truncate text-sm font-semibold tracking-tight text-ink">LeadOps</p>
          <p className="truncate text-2xs text-ink-faint">AI Platform</p>
        </div>
      </div>

      {/* Groups */}
      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-5">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="mb-1.5 px-3 text-2xs font-semibold uppercase tracking-wider text-ink-faint">
              {group.label}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((item) => (
                <li key={item.href}>
                  <NavLink
                    item={item}
                    active={pathname === item.href}
                    badge={item.href === '/alerts' ? alertCount : undefined}
                  />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="shrink-0 border-t border-line px-3 py-3">
        <ul className="space-y-0.5">
          {FOOTER_NAV.map((item) => (
            <li key={item.href}>
              <NavLink item={item} active={pathname === item.href} />
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}
