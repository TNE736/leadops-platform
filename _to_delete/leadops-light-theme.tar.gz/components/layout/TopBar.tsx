'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronRight, UploadCloud, Radio } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ConnectionIndicator } from '@/components/ui/ConnectionIndicator';
import { NAV_GROUPS, FOOTER_NAV, findNavItem, findNavGroup } from '@/components/layout/nav';

const MOBILE_ITEMS = [...NAV_GROUPS.flatMap((g) => g.items), ...FOOTER_NAV];

export function TopBar() {
  const pathname = usePathname();
  const current = findNavItem(pathname);
  const group = findNavGroup(pathname);

  return (
    <header className="sticky top-0 z-20 border-b border-line bg-surface/85 backdrop-blur">
      <div className="flex h-14 items-center gap-4 px-4 sm:px-6">
        {/* Compact brand, shown only where the sidebar is hidden */}
        <Link href="/" className="flex shrink-0 items-center gap-2 lg:hidden">
          <span className="flex h-7 w-7 items-center justify-center rounded-md bg-brand-gradient">
            <Radio className="h-4 w-4 text-white" />
          </span>
          <span className="text-sm font-semibold tracking-tight text-ink">LeadOps</span>
        </Link>

        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="hidden min-w-0 items-center gap-1.5 lg:flex">
          {group && (
            <>
              <span className="text-sm text-ink-faint">{group}</span>
              <ChevronRight className="h-3.5 w-3.5 shrink-0 text-ink-faint" />
            </>
          )}
          <span className="truncate text-sm font-medium text-ink">
            {current?.label ?? 'LeadOps'}
          </span>
        </nav>

        <div className="ml-auto flex shrink-0 items-center gap-3">
          <ConnectionIndicator />
          <Link
            href="/upload"
            className="hidden items-center gap-1.5 rounded-md bg-brand-gradient px-3 py-1.5 text-sm font-medium text-white shadow-raised transition-opacity hover:opacity-90 sm:inline-flex"
          >
            <UploadCloud className="h-4 w-4" />
            Upload leads
          </Link>
        </div>
      </div>

      {/* Mobile / tablet nav strip */}
      <nav className="flex gap-1 overflow-x-auto border-t border-line-soft px-4 py-2 lg:hidden">
        {MOBILE_ITEMS.map((item) => {
          const active = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors',
                active
                  ? 'bg-brand-wash text-brand-ink'
                  : 'text-ink-muted hover:bg-surface-hover hover:text-ink'
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
