'use client';

import { useState } from 'react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { EventFeed } from '@/components/events/EventFeed';
import { useAGUIState } from '@/lib/ag-ui/provider';
import { PIPELINE_STAGE_ORDER, type PipelineStage } from '@/lib/ag-ui/types';
import { cn } from '@/lib/utils';

const ALL = 'all';
type Filter = PipelineStage | typeof ALL;

export default function EventTimelinePage() {
  const { events } = useAGUIState();
  const [filter, setFilter] = useState<Filter>(ALL);

  const filtered = filter === ALL ? events : events.filter((e) => e.type === filter);
  const countFor = (f: Filter) =>
    f === ALL ? events.length : events.filter((e) => e.type === f).length;

  const chips: Filter[] = [ALL, ...PIPELINE_STAGE_ORDER];

  return (
    <>
      <PageHeader
        title="Event timeline"
        description="Every event relayed by the AG-UI Gateway, newest first."
      />

      {/* Filters sit in one row above the log, per the interaction spec. */}
      <div className="mb-4 flex flex-wrap gap-1.5">
        {chips.map((chip) => {
          const active = filter === chip;
          const count = countFor(chip);
          return (
            <button
              key={chip}
              onClick={() => setFilter(chip)}
              aria-pressed={active}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-2xs transition-colors',
                active
                  ? 'border-brand-blue bg-brand-wash font-medium text-brand-ink'
                  : 'border-line bg-surface text-ink-muted hover:border-line-strong hover:text-ink'
              )}
            >
              {chip}
              <span
                className={cn(
                  'tabular-nums',
                  active ? 'text-brand-ink/70' : 'text-ink-faint'
                )}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      <Panel
        title={filter === ALL ? 'All events' : filter}
        description={`${filtered.length} event${filtered.length === 1 ? '' : 's'}`}
        flush
        bodyClassName="border-t border-line-soft"
      >
        <EventFeed
          events={filtered}
          emptyLabel={
            filter === ALL
              ? 'No events yet.'
              : `No ${filter} events in the current window.`
          }
        />
      </Panel>
    </>
  );
}
