'use client';

import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { ConnectionIndicator } from '@/components/ui/ConnectionIndicator';
import { useAGUIState } from '@/lib/ag-ui/provider';
import { formatRelativeTime } from '@/lib/utils';

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <dt className="text-sm text-ink-muted">{label}</dt>
      <dd className="min-w-0 truncate text-right font-mono text-xs text-ink">{value}</dd>
    </div>
  );
}

export default function SettingsPage() {
  const { connection, events, lastEventAt } = useAGUIState();

  return (
    <>
      <PageHeader
        title="Gateway & environment"
        description="Connection details for the AG-UI Gateway. Values are read from environment variables at build and run time."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Panel
          title="Real-time channel"
          description="SSE is attempted first, with WebSocket as the fallback transport."
          actions={<ConnectionIndicator long />}
        >
          <dl className="divide-y divide-line-soft">
            <Row label="Transport state" value={connection} />
            <Row
              label="Events buffered"
              value={`${events.length} / 200`}
            />
            <Row
              label="Last event"
              value={lastEventAt ? formatRelativeTime(lastEventAt) : 'none yet'}
            />
            <Row label="SSE endpoint" value="NEXT_PUBLIC_AG_UI_SSE_URL" />
            <Row label="WebSocket endpoint" value="NEXT_PUBLIC_AG_UI_WS_URL" />
          </dl>
        </Panel>

        <Panel title="Server-side proxy" description="How requests reach the Gateway.">
          <p className="text-sm leading-relaxed text-ink-secondary">
            <code className="rounded bg-surface-sunken px-1.5 py-0.5 font-mono text-xs text-ink ring-1 ring-inset ring-line">
              /api/ag-ui/*
            </code>{' '}
            is rewritten in{' '}
            <code className="rounded bg-surface-sunken px-1.5 py-0.5 font-mono text-xs text-ink ring-1 ring-inset ring-line">
              next.config.mjs
            </code>{' '}
            to{' '}
            <code className="rounded bg-surface-sunken px-1.5 py-0.5 font-mono text-xs text-ink ring-1 ring-inset ring-line">
              AG_UI_GATEWAY_URL
            </code>
            , so the Event Adapter, State Manager, Session Manager, event filtering, auth and rate
            limiting all sit behind one same-origin path.
          </p>

          <div className="mt-4 rounded-md bg-surface-sunken px-3.5 py-3 ring-1 ring-inset ring-line-soft">
            <p className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
              No gateway running?
            </p>
            <p className="mt-1 text-xs leading-relaxed text-ink-secondary">
              Unset <span className="font-mono">NEXT_PUBLIC_AG_UI_SSE_URL</span> and{' '}
              <span className="font-mono">NEXT_PUBLIC_AG_UI_WS_URL</span> to fall back to the local
              mock event stream, or upload a CSV to drive the pipeline directly.
            </p>
          </div>
        </Panel>
      </div>
    </>
  );
}
