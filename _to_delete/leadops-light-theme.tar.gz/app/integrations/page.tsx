'use client';

import { CheckCircle2, AlertTriangle, Clock, MinusCircle, Info } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { useAGUIState } from '@/lib/ag-ui/provider';
import type { EventSource } from '@/lib/ag-ui/types';
import { formatRelativeTime } from '@/lib/utils';

const TOUCHPOINTS: Array<{ source: EventSource; name: string; note: string }> = [
  {
    source: 'lead-profile-agent',
    name: 'Lead Profile Agent → HubSpot',
    note: 'Contact upsert via MCP',
  },
  {
    source: 'email-agent',
    name: 'Email Agent → HubSpot',
    note: 'Reads profile, writes send status via MCP',
  },
  { source: 'voice-agent', name: 'Voice Agent → HubSpot', note: 'Writes call outcome via MCP' },
  {
    source: 'mailgun-webhook',
    name: 'Mailgun → HubSpot',
    note: 'Delivery / open events written via MCP',
  },
  {
    source: 'hubspot-webhook',
    name: 'HubSpot → Gateway',
    note: 'Property-change webhook relayed live',
  },
];

/** Minutes past which a touchpoint with no recent event reads as stale rather than idle. */
const STALE_AFTER_MIN = 5;

/** Health is never colour-alone: each state ships an icon and a written label. */
const HEALTH = {
  healthy: {
    label: 'Healthy',
    icon: CheckCircle2,
    text: 'text-status-success',
    wash: 'bg-status-wash-success',
    ring: 'ring-status-ring-success',
  },
  stale: {
    label: 'Stale',
    icon: Clock,
    text: 'text-status-triggered',
    wash: 'bg-status-wash-triggered',
    ring: 'ring-status-ring-triggered',
  },
  failed: {
    label: 'Failing',
    icon: AlertTriangle,
    text: 'text-status-failed',
    wash: 'bg-status-wash-failed',
    ring: 'ring-status-ring-failed',
  },
  idle: {
    label: 'No data',
    icon: MinusCircle,
    text: 'text-status-waiting',
    wash: 'bg-status-wash-waiting',
    ring: 'ring-status-ring-waiting',
  },
} as const;

export default function IntegrationsPage() {
  const { events } = useAGUIState();

  return (
    <>
      <PageHeader
        title="HubSpot sync health"
        description="HubSpot CRM is the system of record every agent reads and writes via MCP. This is a health strip for each of those touchpoints, plus the two webhooks that feed status back into this app."
      />

      <Panel flush title="Touchpoints" description={`Stale after ${STALE_AFTER_MIN} minutes without an event.`}>
        <ul className="divide-y divide-line-soft border-t border-line-soft">
          {TOUCHPOINTS.map((tp) => {
            const last = events.find((e) => e.source === tp.source);
            const minutesSince = last
              ? (Date.now() - new Date(last.timestamp).getTime()) / 60000
              : null;

            const key = !last
              ? 'idle'
              : last.status === 'failed'
                ? 'failed'
                : minutesSince !== null && minutesSince > STALE_AFTER_MIN
                  ? 'stale'
                  : 'healthy';
            const health = HEALTH[key];
            const Icon = health.icon;

            return (
              <li
                key={tp.source}
                className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 transition-colors hover:bg-surface-sunken"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ring-1 ring-inset ${health.wash} ${health.ring}`}
                  >
                    <Icon className={`h-4 w-4 ${health.text}`} aria-hidden />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink">{tp.name}</p>
                    <p className="mt-0.5 truncate text-xs text-ink-muted">{tp.note}</p>
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-4">
                  <div className="text-right">
                    {last ? (
                      <>
                        <p className="text-xs text-ink-secondary">
                          {formatRelativeTime(last.timestamp)}
                        </p>
                        <p className="mt-0.5 font-mono text-2xs text-ink-faint">{last.type}</p>
                      </>
                    ) : (
                      <p className="text-xs text-ink-faint">No events yet</p>
                    )}
                  </div>
                  <span
                    className={`inline-flex w-20 justify-center rounded-full px-2 py-0.5 text-2xs font-medium ring-1 ring-inset ${health.wash} ${health.text} ${health.ring}`}
                  >
                    {health.label}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      </Panel>

      <Panel className="mt-6" title="Why this page exists" tone="info">
        <div className="flex gap-3">
          <Info className="h-4 w-4 shrink-0 text-status-running" aria-hidden />
          <p className="text-sm leading-relaxed text-ink-secondary">
            The Mailgun → HubSpot → Gateway path is two webhook hops deep, which makes it the
            weakest link in the pipeline: a dropped webhook fails silently rather than erroring. If
            a touchpoint above goes stale while leads are actively moving through the funnel,
            that&rsquo;s the signal a reconciliation job should be polling HubSpot directly to catch.
          </p>
        </div>
      </Panel>
    </>
  );
}
