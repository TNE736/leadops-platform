'use client';

import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { usePipelineCounts } from '@/lib/ag-ui/provider';
import { STAGE_LABELS } from '@/lib/ag-ui/types';

export default function AnalyticsPage() {
  const stages = usePipelineCounts();
  const max = Math.max(1, ...stages.map((s) => s.count));
  const entry = stages[0]?.count ?? 0;

  return (
    <>
      <PageHeader
        title="Pipeline conversion"
        description="Event volume at each stage. Every bar measures the same thing, so they share one colour — length carries the comparison."
      />

      <Panel
        title="Leads by stage"
        description="Share is measured against lead.created, the pipeline entry point."
      >
        <ol className="space-y-3.5">
          {stages.map(({ stage, count }) => {
            const share = entry > 0 ? Math.round((count / entry) * 100) : 0;
            return (
              <li
                key={stage}
                className="grid grid-cols-[minmax(0,180px)_1fr_auto] items-center gap-4"
              >
                <div className="min-w-0">
                  <p className="truncate font-mono text-xs font-medium text-ink" title={stage}>
                    {stage}
                  </p>
                  <p className="mt-0.5 truncate text-2xs text-ink-muted">{STAGE_LABELS[stage]}</p>
                </div>
                <div
                  className="h-2.5 w-full overflow-hidden rounded-full bg-surface-sunken ring-1 ring-inset ring-line-soft"
                  role="img"
                  aria-label={`${STAGE_LABELS[stage]}: ${count} events, ${share}% of entry volume`}
                >
                  <div
                    className="h-full rounded-full bg-brand-blue transition-[width] duration-500"
                    style={{ width: `${(count / max) * 100}%` }}
                  />
                </div>
                <div className="flex w-24 shrink-0 items-baseline justify-end gap-2">
                  <span className="text-sm font-semibold tabular-nums text-ink">{count}</span>
                  <span className="w-10 text-right text-2xs tabular-nums text-ink-faint">
                    {entry > 0 ? `${share}%` : '—'}
                  </span>
                </div>
              </li>
            );
          })}
        </ol>

        {entry === 0 && (
          <p className="mt-5 border-t border-line-soft pt-4 text-xs text-ink-faint">
            No events recorded yet — upload a leads CSV to populate the funnel.
          </p>
        )}
      </Panel>
    </>
  );
}
