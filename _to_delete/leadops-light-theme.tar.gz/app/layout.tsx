import type { Metadata } from 'next';
import './globals.css';
import { AGUIProvider } from '@/lib/ag-ui/provider';
import { Sidebar } from '@/components/layout/Sidebar';
import { TopBar } from '@/components/layout/TopBar';

// Uses the system font stack defined in globals.css (--font-sans / --font-mono)
// so the build never depends on reaching fonts.googleapis.com. Swap in
// next/font/google here if your environment has network access.

export const metadata: Metadata = {
  title: 'LeadOps AI Platform',
  description:
    'From CSV to Voice Agent and HubSpot — real-time lead pipeline observability.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AGUIProvider>
          <Sidebar />
          {/* Offset matches the fixed sidebar width at lg and above. */}
          <div className="lg:pl-60">
            <TopBar />
            <main className="mx-auto max-w-[1280px] px-4 py-6 sm:px-6 lg:py-8">{children}</main>
          </div>
        </AGUIProvider>
      </body>
    </html>
  );
}
