'use client';

import Link from 'next/link';
import { Users, Database, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { StatCard } from '@/components/dashboard/StatCard';
import { EventPipeline } from '@/components/dashboard/EventPipeline';
import { EventFeed } from '@/components/events/EventFeed';
import { useAGUIState } from '@/lib/ag-ui/provider';

const SERVICES = [
  { name: 'Anthropic Claude', role: 'Lead scoring & email generation' },
  { name: 'HubSpot CRM', role: 'System of record — contact & deal sync' },
  { name: 'Mailgun', role: 'Transactional email delivery' },
  { name: 'Voice provider', role: 'Twilio / Retell — outbound calls' },
];

export default function DashboardPage() {
  const { events, activeLeads, stageCounts } = useAGUIState();
  const failed = events.filter((e) => e.status === 'failed').length;

  return (
    <>
      <PageHeader
        title="Dashboard"
        description="Real-time view of every lead moving through CSV ingestion, the lead agents, email delivery, the voice agent, and the HubSpot CRM update."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="Active leads"
          value={activeLeads}
          hint="Currently in the pipeline"
          icon={Users}
        />
        <StatCard
          label="Contacts in HubSpot"
          value={stageCounts['crm.contact.upserted']}
          hint="Upserted via MCP"
          icon={Database}
        />
        <StatCard
          label="Completed"
          value={stageCounts['crm.updated']}
          hint="Reached end of pipeline"
          tone="success"
          icon={CheckCircle2}
        />
        <StatCard
          label="Failed events"
          value={failed}
          hint={failed > 0 ? 'Needs attention' : 'All stages healthy'}
          tone={failed > 0 ? 'failed' : 'default'}
          icon={AlertTriangle}
        />
      </div>

      <Panel
        className="mt-6"
        title="Event pipeline"
        description="Stage-by-stage volume across the most recent events."
        flush
        bodyClassName="border-t border-line-soft"
      >
        <EventPipeline />
      </Panel>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Panel
          className="xl:col-span-2"
          title="Recent activity"
          description="Newest first, across every agent and webhook."
          flush
          actions={
            <Link
              href="/event-timeline"
              className="inline-flex items-center gap-1 text-xs font-medium text-brand-ink hover:underline"
            >
              View all
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          }
        >
          <EventFeed events={events.slice(0, 10)} />
        </Panel>

        <Panel title="Connected services" description="External systems this pipeline depends on.">
          <ul className="divide-y divide-line-soft">
            {SERVICES.map((s) => (
              <li key={s.name} className="py-2.5 first:pt-0 last:pb-0">
                <p className="text-sm font-medium text-ink">{s.name}</p>
                <p className="mt-0.5 text-xs text-ink-muted">{s.role}</p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </>
  );
}
