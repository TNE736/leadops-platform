'use client';

import { PhoneCall, PhoneOutgoing } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useAGUIState } from '@/lib/ag-ui/provider';
import type { VoiceCompletedEvent, VoiceTriggerRequestedEvent } from '@/lib/ag-ui/types';
import { formatRelativeTime } from '@/lib/utils';

export default function VoiceTranscriptPage() {
  const { events } = useAGUIState();
  const triggered = events.filter(
    (e): e is VoiceTriggerRequestedEvent => e.type === 'voice.trigger.requested'
  );
  const completed = events.filter((e): e is VoiceCompletedEvent => e.type === 'voice.completed');

  return (
    <>
      <PageHeader
        title="Voice agent calls"
        description="The Gateway triggers the Voice Agent as soon as HubSpot's email_status property syncs to “opened”. Each trigger is shown with the outcome the agent captured."
      />

      {triggered.length === 0 ? (
        <Panel>
          <div className="flex flex-col items-center gap-1 py-8 text-center">
            <PhoneOutgoing className="mb-1 h-6 w-6 text-ink-faint" aria-hidden />
            <p className="text-sm text-ink-muted">No calls triggered yet.</p>
            <p className="text-xs text-ink-faint">
              A call is triggered once a lead&rsquo;s email is marked opened in HubSpot.
            </p>
          </div>
        </Panel>
      ) : (
        <div className="space-y-4">
          {triggered.map((trigger) => {
            const outcome = completed.find((c) => c.leadId === trigger.leadId);
            return (
              <Panel key={trigger.id} tone={outcome ? 'success' : 'warning'}>
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex min-w-0 items-start gap-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-surface-sunken ring-1 ring-inset ring-line">
                      <PhoneCall className="h-4 w-4 text-ink-muted" aria-hidden />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-mono text-xs font-medium text-ink">
                        {trigger.leadId}
                      </p>
                      <p className="mt-0.5 text-xs text-ink-muted">{trigger.payload.reason}</p>
                    </div>
                  </div>
                  <time
                    dateTime={trigger.timestamp}
                    className="shrink-0 text-2xs tabular-nums text-ink-faint"
                  >
                    {formatRelativeTime(trigger.timestamp)}
                  </time>
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-md bg-surface-sunken px-3.5 py-2.5 ring-1 ring-inset ring-line-soft">
                  {outcome ? (
                    <>
                      <div className="min-w-0">
                        <p className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
                          Outcome
                        </p>
                        <p className="mt-0.5 truncate text-sm font-medium text-ink">
                          {outcome.payload.outcome}
                        </p>
                      </div>
                      <StatusBadge status="success" />
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-ink-muted">Call in progress…</p>
                      <StatusBadge status="triggered" pulse />
                    </>
                  )}
                </div>
              </Panel>
            );
          })}
        </div>
      )}
    </>
  );
}
