'use client';

import { ShieldCheck } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { EventFeed } from '@/components/events/EventFeed';
import { useAGUIState } from '@/lib/ag-ui/provider';

export default function AlertsPage() {
  const { events } = useAGUIState();
  const failed = events.filter((e) => e.status === 'failed' || e.type === 'error.occurred');

  return (
    <>
      <PageHeader
        title="Alerts"
        description="Every failed or errored event in the current window, newest first."
      />

      {failed.length === 0 ? (
        <Panel tone="success">
          <div className="flex flex-col items-center gap-1.5 py-8 text-center">
            <span className="mb-1 flex h-10 w-10 items-center justify-center rounded-full bg-status-wash-success ring-1 ring-inset ring-status-ring-success">
              <ShieldCheck className="h-5 w-5 text-status-success" aria-hidden />
            </span>
            <p className="text-sm font-medium text-ink">No active alerts</p>
            <p className="text-xs text-ink-muted">Every stage in the pipeline is healthy.</p>
          </div>
        </Panel>
      ) : (
        <Panel
          tone="danger"
          flush
          title={`${failed.length} failing event${failed.length === 1 ? '' : 's'}`}
          description="Each row links back to the agent or webhook that reported it."
          bodyClassName="border-t border-line-soft"
        >
          <EventFeed events={failed} />
        </Panel>
      )}
    </>
  );
}
