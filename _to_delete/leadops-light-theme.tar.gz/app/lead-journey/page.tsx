'use client';

import { useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useAGUIState } from '@/lib/ag-ui/provider';
import { PIPELINE_STAGE_ORDER, STAGE_LABELS, SOURCE_LABELS } from '@/lib/ag-ui/types';
import { cn, formatRelativeTime } from '@/lib/utils';

export default function LeadJourneyPage() {
  const { events } = useAGUIState();
  const [selectedLead, setSelectedLead] = useState<string | null>(null);

  const leadIds = useMemo(() => {
    const ids = new Set<string>();
    events.forEach((e) => e.leadId && ids.add(e.leadId));
    return Array.from(ids);
  }, [events]);

  const activeLead = selectedLead ?? leadIds[0] ?? null;
  const leadEvents = events.filter((e) => e.leadId === activeLead);
  const reachedStages = new Set(leadEvents.map((e) => e.type));
  const progress = PIPELINE_STAGE_ORDER.filter((s) => reachedStages.has(s)).length;

  return (
    <>
      <PageHeader
        title="Lead journey"
        description="Select a lead to see how far it has progressed through CSV → Lead Agents → Email → Voice Agent → CRM."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">
        <Panel
          title="Leads"
          description={`${leadIds.length} in the current window`}
          flush
          bodyClassName="max-h-[560px] overflow-y-auto border-t border-line-soft p-2"
        >
          {leadIds.length === 0 ? (
            <p className="px-3 py-6 text-center text-sm text-ink-muted">
              Waiting for leads to arrive…
            </p>
          ) : (
            <ul className="space-y-0.5">
              {leadIds.map((id) => (
                <li key={id}>
                  <button
                    onClick={() => setSelectedLead(id)}
                    aria-current={activeLead === id ? 'true' : undefined}
                    className={cn(
                      'w-full truncate rounded-md px-3 py-2 text-left font-mono text-xs transition-colors',
                      activeLead === id
                        ? 'bg-brand-wash font-medium text-brand-ink'
                        : 'text-ink-secondary hover:bg-surface-hover hover:text-ink'
                    )}
                  >
                    {id}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel
          title={activeLead ?? 'No lead selected'}
          description={
            activeLead ? `${progress} of ${PIPELINE_STAGE_ORDER.length} stages complete` : undefined
          }
          actions={
            activeLead ? (
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-24 overflow-hidden rounded-full bg-surface-sunken ring-1 ring-inset ring-line-soft">
                  <div
                    className="h-full rounded-full bg-brand-gradient transition-[width] duration-500"
                    style={{ width: `${(progress / PIPELINE_STAGE_ORDER.length) * 100}%` }}
                  />
                </div>
                <span className="text-2xs tabular-nums text-ink-muted">
                  {Math.round((progress / PIPELINE_STAGE_ORDER.length) * 100)}%
                </span>
              </div>
            ) : undefined
          }
        >
          {!activeLead ? (
            <p className="py-8 text-center text-sm text-ink-muted">
              Pick a lead on the left to see its journey.
            </p>
          ) : (
            <ol className="relative space-y-5">
              {PIPELINE_STAGE_ORDER.map((stage, idx) => {
                const evt = leadEvents.find((e) => e.type === stage);
                const reached = reachedStages.has(stage);
                const isLast = idx === PIPELINE_STAGE_ORDER.length - 1;
                return (
                  <li key={stage} className="relative flex gap-4 pl-0">
                    {/* Rail */}
                    {!isLast && (
                      <span
                        aria-hidden
                        className={cn(
                          'absolute left-[11px] top-6 h-[calc(100%+4px)] w-px',
                          reached ? 'bg-status-success/40' : 'bg-line'
                        )}
                      />
                    )}
                    <span
                      className={cn(
                        'relative z-10 flex h-[23px] w-[23px] shrink-0 items-center justify-center rounded-full ring-4 ring-surface',
                        reached
                          ? 'bg-status-success text-white'
                          : 'bg-surface-sunken text-ink-faint ring-4 ring-surface'
                      )}
                    >
                      {reached ? (
                        <Check className="h-3 w-3" aria-hidden />
                      ) : (
                        <span className="h-1.5 w-1.5 rounded-full bg-line-strong" aria-hidden />
                      )}
                    </span>

                    <div className="flex min-w-0 flex-1 flex-wrap items-start justify-between gap-3 pb-0.5">
                      <div className="min-w-0">
                        <p
                          className={cn(
                            'font-mono text-xs font-medium',
                            reached ? 'text-ink' : 'text-ink-faint'
                          )}
                        >
                          {stage}
                        </p>
                        <p className="mt-0.5 text-xs text-ink-muted">
                          {STAGE_LABELS[stage]}
                          {evt && (
                            <>
                              <span className="mx-1.5 text-ink-faint">·</span>
                              <span className="text-ink-faint">{SOURCE_LABELS[evt.source]}</span>
                            </>
                          )}
                        </p>
                      </div>
                      {evt && (
                        <div className="flex shrink-0 items-center gap-3">
                          <StatusBadge status={evt.status} pulse={evt.status === 'running'} />
                          <time
                            dateTime={evt.timestamp}
                            className="text-2xs tabular-nums text-ink-faint"
                          >
                            {formatRelativeTime(evt.timestamp)}
                          </time>
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>
      </div>
    </>
  );
}
