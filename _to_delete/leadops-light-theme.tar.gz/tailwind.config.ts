import type { Config } from 'tailwindcss';

/**
 * LeadOps design tokens — light theme.
 *
 * Colour is assigned by JOB, not by decoration:
 *  - `brand`  : chrome only (logo, primary CTA, focus, active rails). Never encodes data.
 *  - `status` : the five EventStatus values. Always shipped with a text label,
 *               never colour alone — that pairing is what keeps `triggered`
 *               (amber) and `failed` (red) distinguishable for CVD readers.
 *  - `ink`/`surface`/`line` : neutral scale carrying all text, cards and rules.
 */
const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // ---- Neutral surfaces ------------------------------------------
        canvas: '#F6F7F9', // app background behind the cards
        surface: {
          DEFAULT: '#FFFFFF', // card / panel
          sunken: '#F9FAFB', // table headers, inset wells
          hover: '#F3F4F6',
        },
        line: {
          DEFAULT: '#E4E7EC', // standard hairline
          soft: '#EFF1F4', // internal dividers
          strong: '#D0D5DD',
        },
        // ---- Ink -------------------------------------------------------
        ink: {
          DEFAULT: '#101828', // headings, primary values
          secondary: '#475467', // body copy
          muted: '#667085', // labels, metadata
          faint: '#98A2B3', // placeholders, disabled
        },
        // ---- Brand (chrome only — green → blue) ------------------------
        brand: {
          green: '#059669',
          blue: '#2563EB',
          DEFAULT: '#1D4ED8',
          ink: '#1E40AF', // links / active nav text
          wash: '#EFF6FF', // tinted active background
        },
        // ---- Status (always paired with a label) -----------------------
        status: {
          success: '#15803D',
          running: '#1D4ED8',
          triggered: '#B45309',
          waiting: '#64748B',
          failed: '#B91C1C',
        },
        'status-wash': {
          success: '#ECFDF3',
          running: '#EFF6FF',
          triggered: '#FFFAEB',
          waiting: '#F2F4F7',
          failed: '#FEF3F2',
        },
        'status-ring': {
          success: '#ABEFC6',
          running: '#BFDBFE',
          triggered: '#FEDF89',
          waiting: '#E4E7EC',
          failed: '#FECDCA',
        },
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(16, 24, 40, 0.04)',
        raised: '0 1px 3px 0 rgba(16, 24, 40, 0.08), 0 1px 2px -1px rgba(16, 24, 40, 0.04)',
        pop: '0 8px 24px -6px rgba(16, 24, 40, 0.12), 0 2px 6px -2px rgba(16, 24, 40, 0.06)',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #059669 0%, #2563EB 100%)',
      },
      animation: {
        pulseDot: 'pulseDot 1.8s ease-in-out infinite',
      },
      keyframes: {
        pulseDot: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.35', transform: 'scale(0.8)' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
